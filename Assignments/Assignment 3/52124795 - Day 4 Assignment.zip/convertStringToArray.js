function convertStringToArray(str){
    return str.split('');
}
console.log(convertStringToArray("TNUICU"))